export const ALL_STATE = "all";
export const PENDING_STATE = "pending";
export const REJECTED_STATE = "rejected";
export const ACCEPTED_STATE = "accepted";
